package week3_Exercise;

public class Test_roman {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Normal_To_Roman n = new Normal_To_Roman ();
n.IntegerToRomanNumeral(125);
}
}